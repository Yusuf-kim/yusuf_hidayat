/*****************************************************************
 * SMART FISH FEEDER BERBASIS INTERNET OF THINGS (IoT)
 *
 * Nama  : Yusuf Hidayat
 * NIM   : 1152625002
 * Prodi : Teknik Informatika
 * Kampus: Institut Teknologi Indonesia
 * Tahun : 2026
 *
 * Judul Skripsi :
 * Perancangan dan Implementasi Sistem Kolam Ikan Pintar
 * Berbasis Internet of Things (IoT) dengan Analisis Kinerja
 * Real-Time
 *
 * Deskripsi :
 * Program ini digunakan untuk mengontrol sistem pemberian
 * pakan ikan otomatis menggunakan ESP32-C3, RTC DS3231,
 * sensor ultrasonik HC-SR04, motor servo, buzzer,
 * Telegram Bot, dan Blynk IoT.
 *
 * Fitur :
 * - Jadwal pemberian pakan otomatis
 * - Kontrol pakan manual melalui Telegram
 * - Kontrol pakan manual melalui Blynk
 * - Monitoring level pakan
 * - Notifikasi pakan rendah (<30%)
 * - Tampilan OLED Display
 *
 * Tahun : 2026
 *
 *****************************************************************/

#define BLYNK_TEMPLATE_ID "TMPL6By0k17lB"
#define BLYNK_TEMPLATE_NAME "Smart Fish Feeder"
#define BLYNK_AUTH_TOKEN "uWrESKCBnRGkIVVNa2tbLgiRz-KZpjSU"

#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>
#include <ESP32Servo.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <HTTPClient.h>
#include <time.h>

#define BOT_TOKEN "8613710547:AAHkoyNteMrCFo3Fb_SxaPyZj4shsigh1kg"

String CHAT_ID = "5841512505";

char ssid[] = "sipppppp2";
char pass[] = "99999999";

const char* GOOGLE_SCRIPT_URL =
"https://script.google.com/macros/s/AKfycbzYSoqol99nAC5AFSNebQudeAaW9lPwF_8eQcqCcDcnRpFzQlEmT1jSEfcPBmYV-t4v/exec";

WiFiClientSecure client;
UniversalTelegramBot bot(BOT_TOKEN, client);

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C

#define SDA_PIN 8
#define SCL_PIN 9

#define TRIGPIN 1
#define ECHOPIN 0

#define BUZZER 10
#define SERVO_PIN 5

#define SERVO_STOP 92
#define SERVO_RUN 120

#define BAR_X 40
#define BAR_Y 40
#define BAR_WIDTH 45
#define BAR_HEIGHT 10

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

RTC_DS3231 rtc;

Servo servo360;

unsigned int jarak = 0;
unsigned int timerSensor = 0;
unsigned int level = 0;

bool buzzerState = false;

unsigned long lastSensor = 0;
unsigned long lastNotif = 0;
unsigned long lastTelegramCheck = 0;

uint8_t Jam1 = 7;
uint8_t Menit1 = 0;
uint8_t Porsi1 = 2;
uint8_t En1 = 1;

uint8_t Jam2 = 13;
uint8_t Menit2 = 20;
uint8_t Porsi2 = 1;
uint8_t En2 = 1;

uint8_t Jam3 = 19;
uint8_t Menit3 = 0;
uint8_t Porsi3 = 3;
uint8_t En3 = 1;

String lastFeedTime = "";


BLYNK_WRITE(V0) {
  Jam1 = param.asInt();
}

BLYNK_WRITE(V1) {
  Menit1 = param.asInt();
}

BLYNK_WRITE(V2) {
  Porsi1 = param.asInt();
}

BLYNK_WRITE(V3) {
  En1 = param.asInt();
}

BLYNK_WRITE(V4) {
  Jam2 = param.asInt();
}

BLYNK_WRITE(V5) {
  Menit2 = param.asInt();
}

BLYNK_WRITE(V6) {
  Porsi2 = param.asInt();
}

BLYNK_WRITE(V7) {
  En2 = param.asInt();
}

BLYNK_WRITE(V8) {
  Jam3 = param.asInt();
}

BLYNK_WRITE(V9) {
  Menit3 = param.asInt();
}

BLYNK_WRITE(V10) {
  Porsi3 = param.asInt();
}

BLYNK_WRITE(V11) {
  En3 = param.asInt();
}

BLYNK_CONNECTED() {

  Blynk.syncVirtual(V0);
  Blynk.syncVirtual(V1);
  Blynk.syncVirtual(V2);
  Blynk.syncVirtual(V3);

  Blynk.syncVirtual(V4);
  Blynk.syncVirtual(V5);
  Blynk.syncVirtual(V6);
  Blynk.syncVirtual(V7);

  Blynk.syncVirtual(V8);
  Blynk.syncVirtual(V9);
  Blynk.syncVirtual(V10);
  Blynk.syncVirtual(V11);
}

BLYNK_WRITE(V13) {

  if (param.asInt() > 0) {

    feed(
      2,
      "MANUAL BLYNK"
    );

    Blynk.virtualWrite(V13, 0);
  }
}


String getDateTime() {

  DateTime now = rtc.now();

  char buffer[25];

  sprintf(
    buffer,
    "%02d/%02d/%04d %02d:%02d:%02d",
    now.day(),
    now.month(),
    now.year(),
    now.hour(),
    now.minute(),
    now.second()
  );

  return String(buffer);
}


void syncRTCFromInternet() {

  configTime(
    7 * 3600,
    0,
    "pool.ntp.org",
    "time.nist.gov"
  );

  struct tm timeinfo;

  Serial.println("Sinkronisasi waktu internet...");

  if (!getLocalTime(&timeinfo, 10000)) {

    Serial.println("Gagal mengambil waktu internet");

    return;
  }

  rtc.adjust(
    DateTime(
      timeinfo.tm_year + 1900,
      timeinfo.tm_mon + 1,
      timeinfo.tm_mday,
      timeinfo.tm_hour,
      timeinfo.tm_min,
      timeinfo.tm_sec
    )
  );

  Serial.println("RTC berhasil disinkronkan");

  Serial.println(getDateTime());
}


void setTelegramCommands() {

  String commands = "[";

  commands +=
    "{\"command\":\"start\",\"description\":\"Menampilkan menu pemberian pakan\"},";

  commands +=
    "{\"command\":\"status\",\"description\":\"Melihat status jadwal pemberian pakan\"},";

  commands +=
    "{\"command\":\"feed\",\"description\":\"Memberikan pakan secara manual\"},";

  commands +=
    "{\"command\":\"level\",\"description\":\"Melihat level ketersediaan pakan\"}";

  commands += "]";

  bot.setMyCommands(
    commands
  );
}


void sendTelegramNotification(
  String jenis,
  int porsi
) {

  String msg = "";

  msg += "🍽️ PEMBERIAN PAKAN BERHASIL\n\n";

  msg += "Jenis: ";
  msg += jenis;
  msg += "\n";

  msg += "Porsi: ";
  msg += String(porsi);
  msg += "\n";

  msg += "Waktu: ";
  msg += getDateTime();

  bot.sendMessage(
    CHAT_ID,
    msg,
    ""
  );
}


void sendDataToGoogleSheet(
  String jenis,
  int porsi
) {

  if (WiFi.status() != WL_CONNECTED) {

    Serial.println(
      "WiFi tidak terhubung. Data tidak dikirim."
    );

    return;
  }

  HTTPClient http;

  http.begin(
    GOOGLE_SCRIPT_URL
  );

  http.addHeader(
    "Content-Type",
    "application/json"
  );

  String jsonData = "{";

  jsonData += "\"jenis\":\"";
  jsonData += jenis;
  jsonData += "\",";

  jsonData += "\"porsi\":";
  jsonData += String(porsi);
  jsonData += "}";

  int httpCode =
    http.POST(jsonData);

  Serial.print(
    "Google Sheet HTTP Code: "
  );

  Serial.println(
    httpCode
  );

  http.end();
}


void feed(
  int porsi,
  String jenis
) {

  if (porsi <= 0) {

    return;
  }

  Serial.println(
    "Pemberian pakan dimulai"
  );

  servo360.write(
    SERVO_RUN
  );

  delay(
    1500 * porsi
  );

  servo360.write(
    SERVO_STOP
  );

  delay(500);

  Serial.println(
    "Pemberian pakan selesai"
  );

  sendTelegramNotification(
    jenis,
    porsi
  );

  sendDataToGoogleSheet(
    jenis,
    porsi
  );
}


void handleTelegram() {

  int numNewMessages =
    bot.getUpdates(
      bot.last_message_received + 1
    );

  while (numNewMessages) {

    for (
      int i = 0;
      i < numNewMessages;
      i++
    ) {

      String chat_id =
        bot.messages[i].chat_id;

      String text =
        bot.messages[i].text;

      if (
        chat_id != CHAT_ID
      ) {

        bot.sendMessage(
          chat_id,
          "Akses ditolak!",
          ""
        );

        continue;
      }


      if (
        text == "/start" ||
        text == "/Start" ||
        text == "/mulai"
      ) {

        String msg = "";

        msg +=
          "🐟 PEMBERIAN PAKAN IKAN\n\n";

        msg +=
          "Silakan gunakan perintah berikut:\n\n";

        msg +=
          "📋 /Status\n";

        msg +=
          "Melihat status jadwal pemberian pakan\n\n";

        msg +=
          "🍽️ /Feed\n";

        msg +=
          "Memberikan pakan secara manual\n\n";

        msg +=
          "📦 /Level\n";

        msg +=
          "Melihat level ketersediaan pakan";

        bot.sendMessage(
          chat_id,
          msg,
          ""
        );
      }


      else if (
        text == "/status" ||
        text == "/Status"
      ) {

        String msg = "";

        msg +=
          "📊 STATUS FEEDER\n\n";

        msg +=
          "Jadwal 1: ";

        msg +=
          String(Jam1);

        msg +=
          ":";

        if (Menit1 < 10) {
          msg += "0";
        }

        msg +=
          String(Menit1);

        msg +=
          " | Porsi ";

        msg +=
          String(Porsi1);

        msg +=
          "\n";


        msg +=
          "Jadwal 2: ";

        msg +=
          String(Jam2);

        msg +=
          ":";

        if (Menit2 < 10) {
          msg += "0";
        }

        msg +=
          String(Menit2);

        msg +=
          " | Porsi ";

        msg +=
          String(Porsi2);

        msg +=
          "\n";


        msg +=
          "Jadwal 3: ";

        msg +=
          String(Jam3);

        msg +=
          ":";

        if (Menit3 < 10) {
          msg += "0";
        }

        msg +=
          String(Menit3);

        msg +=
          " | Porsi ";

        msg +=
          String(Porsi3);

        msg +=
          "\n\n";

        msg +=
          "Waktu RTC:\n";

        msg +=
          getDateTime();

        bot.sendMessage(
          chat_id,
          msg,
          ""
        );
      }


      else if (
        text == "/feed" ||
        text == "/Feed"
      ) {

        bot.sendMessage(
          chat_id,
          "🍽️ Pemberian pakan dimulai...",
          ""
        );

        feed(
          2,
          "MANUAL TELEGRAM"
        );
      }


      else if (
        text == "/level" ||
        text == "/Level"
      ) {

        String msg =
          "📦 LEVEL PAKAN\n\n";

        msg +=
          "Level pakan: ";

        msg +=
          String(level);

        msg +=
          "%";

        bot.sendMessage(
          chat_id,
          msg,
          ""
        );
      }


      else {

        String msg =
          "❌ Perintah tidak dikenal\n\n";

        msg +=
          "Gunakan salah satu perintah berikut:\n\n";

        msg +=
          "/Start - Menampilkan menu\n";

        msg +=
          "/Status - Melihat status jadwal\n";

        msg +=
          "/Feed - Memberikan pakan manual\n";

        msg +=
          "/Level - Melihat level pakan";

        bot.sendMessage(
          chat_id,
          msg,
          ""
        );
      }
    }

    numNewMessages =
      bot.getUpdates(
        bot.last_message_received + 1
      );
  }
}


void readFeedLevel() {

  digitalWrite(
    TRIGPIN,
    LOW
  );

  delayMicroseconds(2);

  digitalWrite(
    TRIGPIN,
    HIGH
  );

  delayMicroseconds(10);

  digitalWrite(
    TRIGPIN,
    LOW
  );

  timerSensor =
    pulseIn(
      ECHOPIN,
      HIGH,
      30000
    );

  jarak =
    timerSensor / 58;

  if (
    jarak > 7
  ) {

    jarak = 7;
  }

  level =
    map(
      jarak,
      7,
      0,
      0,
      100
    );

  if (
    level > 100
  ) {

    level = 100;
  }

  if (
    level < 30
  ) {

    buzzerState =
      !buzzerState;

    digitalWrite(
      BUZZER,
      buzzerState
    );
  }

  else {

    digitalWrite(
      BUZZER,
      LOW
    );
  }

  Blynk.virtualWrite(
    V12,
    level
  );
}


void drawBar(
  int percent
) {

  display.setTextSize(1);

  display.setCursor(
    0,
    BAR_Y + 1
  );

  display.print(
    "Pakan"
  );

  display.drawRect(
    BAR_X,
    BAR_Y,
    BAR_WIDTH,
    BAR_HEIGHT,
    WHITE
  );

  int fill =
    map(
      percent,
      0,
      100,
      0,
      BAR_WIDTH - 2
    );

  display.fillRect(
    BAR_X + 1,
    BAR_Y + 1,
    fill,
    BAR_HEIGHT - 2,
    WHITE
  );

  display.setCursor(
    BAR_X + BAR_WIDTH + 5,
    BAR_Y + 1
  );

  display.print(
    percent
  );

  display.print(
    "%"
  );
}


void updateDisplay() {

  DateTime now =
    rtc.now();

  display.clearDisplay();

  display.setTextSize(1);

  display.setCursor(
    12,
    0
  );

  display.println(
    "SMART FISH FEEDER"
  );

  display.setTextSize(2);

  display.setCursor(
    10,
    15
  );

  display.printf(
    "%02d:%02d:%02d",
    now.hour(),
    now.minute(),
    now.second()
  );

  display.setTextSize(1);

  display.setCursor(
    20,
    34
  );

  display.printf(
    "%02d/%02d/%04d",
    now.day(),
    now.month(),
    now.year()
  );

  drawBar(
    level
  );

  display.display();
}


void checkLowFeedNotification() {

  if (
    level < 30 &&
    millis() - lastNotif > 60000
  ) {

    String msg =
      "⚠️ PERINGATAN PAKAN RENDAH\n\n";

    msg +=
      "Level pakan: ";

    msg +=
      String(level);

    msg +=
      "%\n\n";

    msg +=
      "Segera isi ulang pakan.";

    bot.sendMessage(
      CHAT_ID,
      msg,
      ""
    );

    lastNotif =
      millis();
  }
}


void checkSchedule() {

  DateTime now =
    rtc.now();

  String currentTime = "";

  currentTime +=
    String(now.year());

  currentTime += "-";

  currentTime +=
    String(now.month());

  currentTime += "-";

  currentTime +=
    String(now.day());

  currentTime += "-";

  currentTime +=
    String(now.hour());

  currentTime += "-";

  currentTime +=
    String(now.minute());

  if (
    currentTime == lastFeedTime
  ) {

    return;
  }


  if (
    En1 == 1 &&
    now.hour() == Jam1 &&
    now.minute() == Menit1
  ) {

    lastFeedTime =
      currentTime;

    feed(
      Porsi1,
      "OTOMATIS JADWAL 1"
    );

    return;
  }


  if (
    En2 == 1 &&
    now.hour() == Jam2 &&
    now.minute() == Menit2
  ) {

    lastFeedTime =
      currentTime;

    feed(
      Porsi2,
      "OTOMATIS JADWAL 2"
    );

    return;
  }


  if (
    En3 == 1 &&
    now.hour() == Jam3 &&
    now.minute() == Menit3
  ) {

    lastFeedTime =
      currentTime;

    feed(
      Porsi3,
      "OTOMATIS JADWAL 3"
    );

    return;
  }
}


void setup() {

  Serial.begin(
    115200
  );

  Wire.begin(
    SDA_PIN,
    SCL_PIN
  );

  pinMode(
    TRIGPIN,
    OUTPUT
  );

  pinMode(
    ECHOPIN,
    INPUT
  );

  pinMode(
    BUZZER,
    OUTPUT
  );

  digitalWrite(
    BUZZER,
    LOW
  );

  display.begin(
    SSD1306_SWITCHCAPVCC,
    OLED_ADDR
  );

  display.clearDisplay();

  display.setTextColor(
    WHITE
  );

  display.setTextSize(1);

  display.setCursor(
    0,
    0
  );

  display.println(
    "SMART FISH FEEDER"
  );

  display.println(
    "Connecting WiFi..."
  );

  display.display();


  if (
    !rtc.begin()
  ) {

    Serial.println(
      "RTC tidak ditemukan"
    );
  }


  servo360.attach(
    SERVO_PIN
  );

  servo360.write(
    SERVO_STOP
  );


  Blynk.begin(
    BLYNK_AUTH_TOKEN,
    ssid,
    pass
  );


  client.setInsecure();


  syncRTCFromInternet();


  setTelegramCommands();


  String msg =
    "✅ Pemberian Pakan Aktif\n\n";

  msg +=
    "Tanggal dan waktu berhasil disinkronkan.\n\n";

  msg +=
    "🕒 Waktu: ";

  msg +=
    getDateTime();

  msg +=
    "\n\nKetik /Start untuk melihat menu.";


  bot.sendMessage(
    CHAT_ID,
    msg,
    ""
  );
}


void loop() {

  Blynk.run();


  if (
    millis() - lastTelegramCheck > 1000
  ) {

    lastTelegramCheck =
      millis();

    handleTelegram();
  }


  if (
    millis() - lastSensor > 1000
  ) {

    lastSensor =
      millis();

    readFeedLevel();

    updateDisplay();

    checkLowFeedNotification();
  }


  checkSchedule();
}